package com.oebp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineelectricitybillpaymentApplicationTests {

	@Test
	void contextLoads() {
	}

}
