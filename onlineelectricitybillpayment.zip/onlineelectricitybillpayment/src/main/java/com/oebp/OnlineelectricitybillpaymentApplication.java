package com.oebp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineelectricitybillpaymentApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineelectricitybillpaymentApplication.class, args);
	}

}
