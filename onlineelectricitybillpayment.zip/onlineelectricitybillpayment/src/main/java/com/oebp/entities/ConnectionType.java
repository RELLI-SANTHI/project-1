package com.oebp.entities;

public enum ConnectionType {
	
	NON_INDUSTRIAL,INDUSTRIAL,AGRICULTURAL;
	
}
