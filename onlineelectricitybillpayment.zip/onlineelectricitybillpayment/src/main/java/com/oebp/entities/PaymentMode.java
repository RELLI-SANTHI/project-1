package com.oebp.entities;

public enum PaymentMode {
	CREDIT,DEBIT,WALLET,NETBANKING

}
