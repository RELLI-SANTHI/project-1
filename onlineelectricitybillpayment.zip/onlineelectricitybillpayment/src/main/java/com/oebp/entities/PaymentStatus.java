package com.oebp.entities;

public enum PaymentStatus {
	TRUE,FALSE

}
