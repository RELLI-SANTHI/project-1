package com.oebp.exceptions;

 

public class BillNotFoundByBillDateException extends RuntimeException{

public BillNotFoundByBillDateException(String message) {

super(message);

}

 

}