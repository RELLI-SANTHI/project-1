package com.oebp.exceptions;

public class NoSuchReadingException extends RuntimeException {

	public NoSuchReadingException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}



}



