package com.oebp.exceptions;

public class InvalidUserNameException extends RuntimeException {

}