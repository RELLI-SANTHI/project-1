package com.oebp.exceptions;

public class DuplicateUserException extends Exception {

}
