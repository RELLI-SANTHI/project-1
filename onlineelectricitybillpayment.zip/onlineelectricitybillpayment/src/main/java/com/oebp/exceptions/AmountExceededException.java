package com.oebp.exceptions;

public class AmountExceededException extends RuntimeException{
	public AmountExceededException() {
	}


}
