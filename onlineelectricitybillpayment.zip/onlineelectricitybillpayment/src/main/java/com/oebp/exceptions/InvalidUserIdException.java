package com.oebp.exceptions;

public class InvalidUserIdException extends RuntimeException {

}