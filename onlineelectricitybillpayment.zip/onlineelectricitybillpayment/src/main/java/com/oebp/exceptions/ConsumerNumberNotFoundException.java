package com.oebp.exceptions;

public class ConsumerNumberNotFoundException extends RuntimeException {

	public ConsumerNumberNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	}
	


	