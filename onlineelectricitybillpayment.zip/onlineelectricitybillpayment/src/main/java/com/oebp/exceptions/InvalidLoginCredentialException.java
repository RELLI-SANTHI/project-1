package com.oebp.exceptions;

public class InvalidLoginCredentialException extends RuntimeException {

}