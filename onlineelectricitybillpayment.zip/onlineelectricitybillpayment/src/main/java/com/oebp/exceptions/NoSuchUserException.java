package com.oebp.exceptions;

public class NoSuchUserException extends Exception {

}