package com.oebp.exceptions;


public class PaymentIdNotFoundException extends RuntimeException{

	public PaymentIdNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}