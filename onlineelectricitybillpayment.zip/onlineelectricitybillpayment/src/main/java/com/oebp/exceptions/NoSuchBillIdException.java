package com.oebp.exceptions;

 

public class NoSuchBillIdException extends RuntimeException{

public NoSuchBillIdException(String msg) {

super(msg);

}

 

}