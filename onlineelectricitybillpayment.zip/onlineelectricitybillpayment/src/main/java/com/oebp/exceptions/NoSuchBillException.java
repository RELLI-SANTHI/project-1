package com.oebp.exceptions;

 

public class NoSuchBillException extends RuntimeException{

public NoSuchBillException(String msg) {

super(msg);

}

 

}