package com.oebp.exceptions;

public class InvalidTransactionException extends RuntimeException{

	public InvalidTransactionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
