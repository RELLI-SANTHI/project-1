import java.util.Arrays;
import java.util.List;

public class P1 {
	
	public static void main(String[] args) {
		
		
		

	}

}
