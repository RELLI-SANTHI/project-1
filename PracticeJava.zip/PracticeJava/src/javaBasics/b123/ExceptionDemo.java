package javaBasics.b123;

class A{
	private int x;
	private int y=0;
	
	public void validate(int x) throws KomalException {
		if(x<18) {
			throw new KomalException("Wrong age");
		}
		else {
			System.out.println("All good");
		}
	}
	public void divide() throws ArithmeticException{
		System.out.println(18/y);
	}
}

class KomalException extends Exception{
	public KomalException(String str) {
		super(str);
	}
}



public class ExceptionDemo {

	public static void main(String[] args) throws Exception {
		int a=1;
		int b=0;
		int [] c = new int[10];
		
		
		A a1=new A();
//		try {
//		a1.divide();
//		}catch(ArithmeticException e) {System.out.println(e+" hi");}
	
		try {
			a1.validate(15);
		}catch(KomalException e) {
			System.out.println("custom exception : "+e);
		}

		
		
	}

}
