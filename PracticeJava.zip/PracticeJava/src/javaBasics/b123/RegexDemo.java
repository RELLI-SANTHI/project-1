package javaBasics.b123;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexDemo {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
//		String s= sc.nextLine();
		String s = args[1];
//		String s="HiBRO";
		Pattern pattern = Pattern.compile("\\sbro",Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(s);
		
		if(matcher.find()) 
			System.out.println( s+ ":"+matcher.group() + "  + : *Emotional Damage*");
		
		else
			System.out.println(s+ ":"+ ": *All GOOD*");

	}

}
