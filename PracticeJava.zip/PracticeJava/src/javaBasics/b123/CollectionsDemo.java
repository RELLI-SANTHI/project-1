package javaBasics.b123;

import java.util.*;

public class CollectionsDemo extends Object{

	public static void main(String args[]) {
		List<Integer> l1 = new ArrayList<>();
		l1.add(45);
		l1.add(23);
		l1.add(48);
		l1.add(95);
		l1.add(56);
		
		System.out.println("L1"+l1);
//		Collections.sort(l1);
//		System.out.println(l1);
		
		/*Creating & Adding elements to list List*/
		List<Integer> l2 = Arrays.asList(45,23,48,95,56);
//		System.out.println("L2"+l2);
//		
//		Collection<Integer> l3 = new ArrayList<>(l2);
//		System.out.println("L3"+l3);
//		
//		List<Integer> l4 = new ArrayList<>();
//		l4.addAll(l3);
//		System.out.println("L4"+l4);
		
		
		/*Printing List*/
		
//		for(int num : l1) {
//			System.out.print(num+" ");
//		}
//	
//		System.out.println();
//		
//		for(int i=0;i<l1.size();i++) {
//			System.out.print(l1.get(i)+" ");
//		}
//		
//		l1.forEach(n -> System.out.print(n+" "));
//		
//		Iterator<Integer> ite = l1.iterator();
//		while(ite.hasNext()) {
//			System.out.print(ite.next()+" ");
//		}
//		
//		l1.clear();
//		System.out.println("L1"+l1);
//		
//		System.out.println(l1.contains(4));
//		
//		System.out.println(l1.equals(l2));
//		
//	
//		Queue<String> q1 = new PriorityQueue<>();
//		q1.offer("Komal");
//		q1.offer("Ajay");
//		q1.offer("Arut");
//		q1.offer("Prasanna");
//		q1.offer("Sanju");
//		
//		System.out.println("Queue 1 : "+q1);
//		
//		System.out.println(q1.poll());
//		System.out.println(q1.peek());
//		System.out.println("Queue 1 : "+q1);
//		
//		q1.forEach(s -> System.out.print(s+" "));
//		
//		Set<Integer> s1 = new HashSet<>();
//		s1.add(11);
//		s1.add(34);
//		s1.add(23);
//		s1.add(76);
//		
//		s1.forEach(num -> System.out.print(num+" "));
//		
//		Map<String,Integer> m1 = new HashMap<>();
//		m1.put("Komal", 55);
//		m1.put("Ajay", 99);
//		m1.put("Sanju", 54);
//		m1.put("Arut", 76);
//		m1.put("Vasanth", 100);
//		
//		System.out.println(m1.keySet());
//		
//		for(String key : m1.keySet()) {
//			System.out.println(key +" : "+m1.get(key));
//		}
//		System.out.println();
//		
//		m1.forEach((k,v) -> System.out.println(k+" -- "+v));
//		System.out.println(m1);
//		
//		Set<Map.Entry<String, Integer>> s2 = m1.entrySet();
//		System.out.println(s2);
//		System.out.println(m1);
//		
//		
//		
//		Iterator<Map.Entry<String,Integer>> ite = s2.iterator();
//		while(ite.hasNext()) {
//			Map.Entry<String, Integer> entry = ite.next();
//			System.out.println(entry.getKey()+" : "+entry.getValue());
//		}
		
//		System.out.println(l1.stream().count());
//		
//		List<Integer> l5 = l1.stream().filter(n -> n>45)
//									.map(n ->n+100)
//									.collect(Collectors.toList());
//		System.out.println(l5);
//		
//		int result = l1.stream()
//						.map(n -> n+100)
//						.sorted()
//						.reduce(1000,(a,e)->a+e);
//		System.out.println(result);
//		
//		List<Integer> l6 = Stream.of(10,20,30)
//						.collect(Collectors.toList());
//		System.out.println(l6);
//		
//		Stream.of(11,22,33,44,55).forEach(n->System.out.println(n));
//		System.out.println();
//		Stream.concat(Stream.of(10), Stream.of(1000))
//				.forEach(n->System.out.println(n));
//		Stream.generate(new Random()::nextDouble)
//				.limit(10)
//				.forEach(n-> System.out.println(n));
//		l1.stream().dropWhile(n->n<=45)
//					.forEach(n->System.out.println(n));
//		System.out.println();
////		l1.stream().distinct().forEach(n->System.out.println(n));
//
//		System.out.println(l1);
//
////		Stream<String> s1 = Stream.of("Sanju", "Komal", "Bhavana");
////		List<String> list1 = s1.collect(ArrayList::new,ArrayList::add,ArrayList::addAll);
//			
//		
		
//		Collections.sort(l1);
//		System.out.println(l1);
		List<Student> list1 =new ArrayList<>();
		
		list1.add(new Student("Komal",18));
		list1.add(new Student("Chaithanaya",20));
		list1.add(new Student("Arut",30));
		list1.add(new Student("sai",19));
		
		list1.stream().sorted().forEach(n->System.out.println(n));;
		
		
		
		
		
		
		

		

		
		
		
	}

}
