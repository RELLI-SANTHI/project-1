package javaBasics.b123;

import java.util.ArrayList;
import java.util.List;

public class ComparatorDemo {

	public static void main(String[] args) {
		List<Student> studs=new ArrayList<>();
		
		Student s1 =new Student("komal",20);
		Student s2 =new Student("Ajay",18);
		Student s3 =new Student("Arut",30);
		Student s4 =new Student("Bhavana",24);
		Student s5 =new Student("Aditi",25);
		studs.add(s1);
		studs.add(s2);
		studs.add(s3);
		studs.add(s4);
		studs.add(s5);
		System.out.println(studs);
//		Comparator<Student> com = new Comparator<Student>() {

//			public int compare(Student o1, Student o2) {
//				if(o1.getAge()>o2.getAge()) {
//					return 1;
//				}
//				else
//				return -1;
//			}
//		};
			
			
		String name="komal";
		StringBuilder input=new StringBuilder();
		input.append(name);
		System.out.println(input.reverse());		
		
		
		
//		Collections.sort(studs,com);
//		System.out.println(studs);
		
		

	}

}
