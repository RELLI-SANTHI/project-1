package javaBasics.b123;


import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;
class Hello {
    public static void main(String[] args) {
    	
    	
    	
    	
    	
    	
   }
}