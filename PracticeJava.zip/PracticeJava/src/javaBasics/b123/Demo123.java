package javaBasics.b123;



class Demo1{
	static private void add() {
		System.out.println("Hii");
	}
	public static void add1() {
		
		Demo1.add();
		System.out.println("hi sanju");
		
	}
}

class Demo2 extends Demo1{
	static public void add() {
		
		System.out.println("hello");
	}
	static public void add(int a){
		
	}
	
    static public void add(int a,float b){
		
	}
    
    public static void add1() {
    	System.out.println("hi sanju bro!!!");
    }
}


public class Demo123 {
	public static void main(String[] args) {
		
//		Demo2.add();
//		
		Demo1.add1();
		
		Demo1 dd1 = new Demo2();
		Demo2 dd2 = new Demo2();
		
		dd1.add1();
		dd2.add1();
	}

}
