package javaBasics.b123;

public class BasicsDemo {

	public static void main(String[] args) {

//


























//			var i = 10;
//			System.out.println(i);
//			var s = "string";
//			var f = 10.4f;


//********________primitive Data types_________*******************************************************************************
//		byte a=10;
//		byte b=12;
//		int c=a+b;
//		byte d=(byte)c;
//		System.out.println(c);
//		System.out.println(d);

//		byte c=(byte)129;
//		System.out.println(c);

//		int i=10;
//		float f=i;
//		System.out.println(i);
//		System.out.println(f);

//		double d=10.5;
//		System.out.println(d);

//		float f= 10.8f;
//		int i=(int)f;
//		System.out.println(f);
//		System.out.println(i);

//		for(int i=0; i<200; i++){
//			char ch = (char)i;
//			System.out.println(i+":	"+ch);
//		}



//*********_______unary operators_______*********************************************************************************
//		int a=10;
//		System.out.println("a = "+a);
//		System.out.println("a++ = "+ a++);
//		System.out.println("++a = "+ ++a);
//		System.out.println("a-- = "+ a--);
//		System.out.println("--a = "+ --a);
//
//		boolean b =false;
//		System.out.println("b = "+b);
//		System.out.println("!b = "+!b);

		//shift operators(<<, >>, >>>)
		//left shift operator
//		System.out.println("10<<2 = "+(10<<2)); //10*2^2 = 10*4 = 40
//		System.out.println("30<<3 = "+(30<<3)); //30*2^3 = 30*8 =240
//		System.out.println();

		//right shift operator
//		System.out.println("10>>3 = "+(10>>3)); // 10/(2^3) = 10/8 = 1
//		System.out.println("100>>2 = " + (100>>2)); // 100/(2^2) = 100/4 = 25
//		System.out.println();
//
//		System.out.println("20>>2 = "+(20>>2));
//		System.out.println("20>>>2 = "+(20>>>2));
//		System.out.println();
//
//		System.out.println("20>>2 = "+(-20>>2));
//		System.out.println("20>>>2 = "+(-20>>>2));

		//Logical "&&" Vs Bitwise "&"
//		int a=10;
//		int b=5;
//		int c=20;
//		System.out.println(a<b && a++<c);//false && true = false
//		System.out.println(a);//10 because second condition is not checked
//		System.out.println(a<b & a++<c);//false && true = false
//		System.out.println(a);//11 because second condition is checked

		//Logical "||"  Vs Bitwise "|"
//		int a=10;
//		int b=5;
//		int c=20;
//		System.out.println(a>b || a<c);//true || true = true
//		System.out.println(a>b | a<c);//true | true = true
//		//	|| vs |
//		System.out.println(a>b || a++<c);//true || true = true
//		System.out.println(a);//10 because second condition is not checked
//		System.out.println(a>b | a++<c);//true | true = true
//		System.out.println(a);//11 because second condition is checked   Bitwise |


		//Trinary Operator
		//It is the one line replacement of if-then-else statement.
		//It is the only conditional operator which takes 3 operands
//		int a=10;
//		int b=12;
//		int min = (a<b)?a:b;
//		System.out.println("Min : "+min);
//		int max = (a>b)?a:b;
//		System.out.println("max : "+max);


//**********_________switch statement_______******************************************************************************
//		int i=1;
//		enum day {SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY};
//		switch(day.MONDAY){
//
//			case SUNDAY:
//				System.out.println("sunday");
//				break;
//			case MONDAY:
//				System.out.println("monday");
//				break;
//			case TUESDAY:
//				System.out.println("tuesday");
//				break;
//			case WEDNESDAY:
//				System.out.println("wednesday");
//				break;
//			case THURSDAY:
//				System.out.println("thursday");
//				break;
//			case FRIDAY:
//				System.out.println("friday");
//				break;
//			case SATURDAY:
//				System.out.println("saturday");
//				break;
//
//			default:
//				System.out.println("Not matched");
//		}







	}

}
