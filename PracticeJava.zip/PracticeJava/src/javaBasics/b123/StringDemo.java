package javaBasics.b123;

import java.util.Arrays;
import java.util.Scanner;

public class StringDemo {
	
	
	public static String reverse(String str) {
//		String word = str;
//		char[] charArray = str.toCharArray();
//		Arrays.sort(charArray);
//		String reverse = new String(charArray);
//		return reverse;
		return  new StringBuilder().append(str).reverse().toString();

	}
	
	public static String wordReverse(String str) {
		String sentence = str;
		String wordReverse = "";
		
		String[] subStrings = sentence.split(" ");
		for(int i=(subStrings.length)-1;i>=0;i--) {
			wordReverse = wordReverse+subStrings[i]+" ";
		}
		
		return wordReverse;
	}

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Sentence : ");
		String sentence = sc.nextLine();
//		String wordReverse = wordReverse(sentence).trim();
//
//		System.out.println("word reverse of the sentence : "+wordReverse);
//
//		System.out.println(sentence.length());
//		System.out.println(wordReverse.length());
		
		String reverse =reverse(sentence);
		System.out.print("reverse of the sentence : "+reverse);
		

	}

}
