package javaBasics.javaBasics.basics.documentation.regex;

import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexDemo {

    public static void main(String[] args) {


        /**
         * *****************__________JAVA Regex_________**********************************************
        * The Java Regex or Regular Expression is an API to define a pattern for searching or manipulating strings.
        * 1.MatchResult interface
        * 2.Matcher class
        * 3.Pattern class
        * 4.PatternSyntaxException class
        */


        /**
         * Regex Character classes
         *
         * No.	 Character Class -   Description
         * 1	[abc]	         -      a, b, or c (simple class)
         * 2	[^abc]	         -     Any character except a, b, or c (negation)
         * 3	[a-zA-Z]	     -      a through z or A through Z, inclusive (range)
         * 4	[a-d[m-p]]	     -     a through d, or m through p: [a-dm-p] (union)
         * 5	[a-z&&[def]]     -    d, e, or f (intersection)
         * 6	[a-z&&[^bc]]     -    a through z, except for b and c: [ad-z] (subtraction)
         * 7	[a-z&&[^m-p]]    -    a through z, and not m through p: [a-lq-z](subtraction)
         */

        /**
         * Regex Quantifiers
         * The quantifiers specify the number of occurrences of a character.
         *
         * Regex   -     Description
         * X?	   -     X occurs once or not at all
         * X+	   -     X occurs once or more times
         * X*	   -     X occurs zero or more times
         * X{n}	   -     X occurs n times only
         * X{n,}   -     X occurs n or more times
         * X{y,z}  -     X occurs at least y times but less than z times
         */

        /**
         * Regex Metacharacters
         * The regular expression metacharacters work as shortcodes.
         * <p>
         * Regex -	Description
         * .	 -   Any character (may or may not match terminator)
         * \d	 -   Any digits, short of [0-9]
         * \D	 -   Any non-digit, short for [^0-9]
         * \s	 -   Any whitespace character, short for [\t\n\x0B\f\r]
         * \S	 -   Any non-whitespace character, short for [^\s]
         * \w	 -   Any word character, short for [a-zA-Z_0-9]
         * \W	 -   Any non-word character, short for [^\w]
         * \b	 -   A word boundary
         * \B	 -   A non word boundary
         *
         * ^[aeiou].*[aeiou]$  mwsql
         */


//        Pattern p = Pattern.compile(".ava");
//        System.out.println("pattern(): "+p.pattern());
//        Matcher m = p.matcher("Java Programing language");
//        System.out.println(m.find());       //true
//        System.out.println(m.matches());    //false
//        System.out.println();
//
        /**
         * Matcher class methods
         *
         * No.	Method	                    Description
         * 1    boolean matches()   	    test whether the regular expression matches the pattern.
         * 2	boolean find()	            finds the next expression that matches the pattern.
         * 3	boolean find(int start)	    finds the next expression that matches the pattern from the given start number.
         * 4	String group()	            returns the matched subsequence.
         * 5	int start()	                returns the starting index of the matched subsequence.
         * 6	int end()	                returns the ending index of the matched subsequence.
         * 7	int groupCount()	        returns the total number of the matched subsequence.
         */
//        Matcher m1 = Pattern.compile("Hai").matcher("Hai Komal Hai");
//        System.out.println("matches: "+m1.matches());
//        int i=1;
//        while(m1.find()){
//            System.out.println("group"+i+": "+m1.group()+" - start(): "+m1.start()+" - end(): "+m1.end());
//            i++;
//            System.out.println();
//        }
//        System.out.println("find: "+m1.find());
//        System.out.println("groupCount(): "+m1.groupCount());
//        boolean b = Pattern.matches("\\s.*"," Hello");
//        System.out.println(b);
//        Pattern p = Pattern.compile("hai"+"ok");
//        Pattern p1 = Pattern.compile("ok");
//        Matcher m = p.matcher("haiok");
//        System.out.println(m.matches());
//
        String email = "sanjusriram@gmail.com";
        String regex = "(\\w+)@(\\w+).(\\w+)";
        //String regex = "(.*)(@)(.*)(.)(.*)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(email);

        while(matcher.find()) {

            System.out.println(matcher.group(0));
            System.out.println(matcher.group(1));
            System.out.println(matcher.group(2));
            System.out.println(matcher.group(3));
            System.out.println(matcher.groupCount());
        }



        /**
         * Pattern class methods
         *
         * No.	Method	                                                     Description
         * 1	static Pattern compile(String regex)	                    compiles the given regex and returns the instance of the Pattern.
         * 2	Matcher matcher(CharSequence input)	                        creates a matcher that matches the given input with the pattern.
         * 3	static boolean matches(String regex, CharSequence input)	It works as the combination of compile and matcher methods. It compiles the regular expression and matches the given input with the pattern.
         * 4	String[] split(CharSequence input)	                        splits the given input string around matches of given pattern.
         * 5	String pattern()	                                        returns the regex pattern.
         */
        /**
         * 1. compile() method
         * compiles the given regex and returns the instance of the Pattern.
         */
//        Pattern p = Pattern.compile(".*");
//        Pattern p1 = Pattern.compile(".*",Pattern.CASE_INSENSITIVE);


        /**
         * 2. matcher() method
         * creates a matcher that matches the given input with the pattern.
         */
//        Matcher m = Pattern.compile(".*").matcher("Some Input String");
//        Matcher m1 = Pattern.compile(".*",Pattern.CASE_INSENSITIVE).matcher("Some Input String1");


        /**
         * 3. matches() method
         * It works as the combination of compile and matcher methods. It compiles the regular expression and matches the given input with the pattern.
         */
//        Pattern p3 = Pattern.compile(".*");
//        Matcher m3 = p3.matcher("Some string");
//        boolean b = m3.matches();
//        //*********
//        boolean b1 = Pattern.matches(".*","Some string");
//        //***********


        /**
         * 4. split() method in pattern class
         * splits the given input string around matches of given pattern.
         */
//        String[] words = Pattern.compile(" ").split("hello world, my name is komal");
//
//        //printing array by converting into string
//        System.out.println(Arrays.toString(words));
//        System.out.println();
//
//        //printing array using foreach loop
//        for(String word: words)
//            System.out.println(word);


        /**
         * 5. pattern() method in pattern class
         * returns the regex pattern as string.
         */
//        Pattern p5 = Pattern.compile(".ava");
//        System.out.println("pattern(): "+p.pattern());




        String str = "hai hai";
        Pattern p1 = Pattern.compile("\\s",Pattern.CASE_INSENSITIVE);
        Matcher m = p1.matcher(str);
        System.out.println(m.matches());
//        System.out.println(m.find());

        while (m.find()){
            System.out.println(m.start()+" - "+m.end());
        }

        String str1 = "komal";
        Pattern p2 = Pattern.compile("[aeiou]",Pattern.CASE_INSENSITIVE);
        String[] strArray =  p2.split(str1);
        System.out.println(Arrays.toString(strArray));



    }

}
