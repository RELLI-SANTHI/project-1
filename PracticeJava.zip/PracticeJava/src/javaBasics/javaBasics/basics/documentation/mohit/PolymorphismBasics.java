package javaBasics.javaBasics.basics.documentation.mohit;

public class PolymorphismBasics {

    public static void main(String[] args) {
        //here we are creating a object of class AreaOfDifferentShapes which have methods add.
        //both are different classes
        //in order to use method add from another class first we need to create a object of that class
        AreaOfDifferentShapes areaOfDifferentShapes = new AreaOfDifferentShapes();

        //calculating area of square and storing it in a int variable
        int lengthOfSide = 2;
        int areaOfSquare = areaOfDifferentShapes.area(lengthOfSide);
        System.out.println("Area of square: "+areaOfSquare);

        //calculating area of rectangle and storing it in a int variable
        int length = 5;
        int breadth = 7;
        int areaOfRectangle = areaOfDifferentShapes.area(length,breadth);
        System.out.println("Area of rectangle: "+areaOfRectangle);

       //calculating are of circle and storing it in double variable
        float radius = 4f;
        double areaOfCircle = areaOfDifferentShapes.area(radius);
        System.out.println("Area of circle: "+areaOfCircle);






//        MethodOverloadingDemo obj1 = new MethodOverloadingDemo();
//        int a = 10;
//        int b = 20;
//        int c = 30;
//        System.out.println("a+b: "+obj1.add(a,b));
//        System.out.println("a+b+c: "+obj1.add(a,b,c));

    }



}

class MethodOverloadingDemo{
    //method overloading - having same methodname but different no. of parameters or different dataTypes
    //here we overloaded method having same name by changing no of parameters
    //name of method is same
    //do u know what is return type
    //a method will have a return type, basically means which datatype is that method returning

    //basic method signature
    // accessModifier returnType methodName(parameterList) {statementsToBeExecuted }

    //here this method is returning a int value a+b
    //so return type is int
    public int add(int a, int b){
        return a+b;
    }
    public float add(float a,float b){
        return a+b;
    }

    public int add(int a, int b, int c){
        return a+b+c;
    }

    //some methods won't return anything
    //in that case return type is void
//    public void add(int a,int b,int c){
//        int sum = a+b+c;
//
//    }






}

class AreaOfDifferentShapes{
    //first method to calculate area of square= a*a
    public int area(int lengthOfSide){
        return lengthOfSide*lengthOfSide;
    }
    //second method to calculate area of rectangle = a*b
    public int area(int length, int breadth){
        return length*breadth;
    }
    //third method to calculate are of circle
    public double area(float r){
        return 3.14*r*r;
    }
}
