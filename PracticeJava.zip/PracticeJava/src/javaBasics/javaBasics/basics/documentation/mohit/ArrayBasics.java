package javaBasics.javaBasics.basics.documentation.mohit;

import java.util.Scanner;

public class ArrayBasics {

    public static void main(String[] args) {

        String str="Hello World";
        int i=1;
        while( i<=100) {
            System.out.println(str);
            System.out.println(i);
            i++;

        }











        //declare a array
        //u need to mention size while declaring or else it will be error
        //array work on indexes
        //like first element in array is index "0"
        //last element is of index size-1
        //suppose array size is 5
        //indexs are 0 1 2 3 4
//        int marksOfStudents[] = new int[5];
//
//        //initialization
//        marksOfStudents[0] = 90;
//        marksOfStudents[1] = 86;
//        marksOfStudents[2] = 97;
//        marksOfStudents[3] = 70;
//        marksOfStudents[4] = 95;

        //printing
        //System.out.println("marks of student 3: "+marksOfStudents[3]);

        //printing array using for loop
//        for(int i=0; i<marksOfStudents.length; i++){
//            System.out.println("marks of student "+(i+1)+": "+marksOfStudents[i]);
//        }

        //2D array declaration
//        int a[][] = new int[2][2];//2D


        //initializing array with scanner
//        int marks[] = new int[5]; //1D

        //scanner is used to read data from console, which user will enter
        //here we are creating a scanner object
//        Scanner sc = new Scanner(System.in);

        //assigning values to array using scanner and for loop
        //length method will return length of that array
        //here length is 5 , so we are looping 5 times to assign each
//        System.out.println("length of marks array: "+marks.length);

        //i++ means i=i+1;
        //i-- means i=i-1;
        //here we are starting from 0 and incrementing by 1
//        for (int i=0; i<marks.length; i++){
//            System.out.println("Enter marks of student "+(i+1)+": ");
//            //here we are using that scanner object to read data from console
//            marks[i] = sc.nextInt();
//        }
//
//        //printing of array using for loop
//        for(int i=0; i<marks.length; i++){
//            System.out.println("marks of student "+(i+1)+": "+marks[i]);
//        }





    }
}
