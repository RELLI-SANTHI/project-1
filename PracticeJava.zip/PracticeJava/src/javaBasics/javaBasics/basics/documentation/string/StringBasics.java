package javaBasics.javaBasics.basics.documentation.string;

import javax.sound.midi.Soundbank;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;

public class StringBasics {

	public static void main(String[] args) {
	

	//**************________String__________***************************************************************************
		/**
		 * ways to create a string object
 		 */
//		String s1 = new String(new char[]{'k','o','m','a','l'});
//		String s2 = new String(new char[]{'k','o','m','a','l'},1,2); //om
//		String s3 = new String();
//		System.out.println(s3.hashCode());
//		s3="Komal";
//		System.out.println(s3.hashCode());
//		String s4 = "Komal";
//		String s5 = new String("komal");
//		System.out.println(s3);



	    /**
	     * When we use String literals to initialize a String object ,
	     * JVM first look into String Constant Pool whether the same value is present or not .
	     * If present it will simply return the reference of it.
	     * if not present then it will create new object for it.
	     */
//			String s = "Komal";
//			String ss = "Komal";
//			System.out.println(s.hashCode());	//72678740
//			System.out.println(ss.hashCode());	//72678740


	    /**
	     * even through after using new keyword for creating new strings Surprisingly both hash codes are same
	     * The Objects are created in separate memory locations
	     * The same hashcode is coming because the String class overrides the hashCode() method from Object class
	     */
//			String s4 = new String("hai");
//			String s5 = new String("hai");
//			System.out.println(s4.hashCode());	//103056
//			System.out.println(s5.hashCode());	//103056


	    /**
	     * String is Immutable(we cannot change the value of String)
	     * If u try to change the value then a new Object will be created, and it will be referred.
	     */
//			String s1 = new String("Sanju");
//			System.out.println(s1.hashCode());	//79651083
//			s1 = "komal";
//			System.out.println(s1.hashCode());	//102231412


	    /**
	     * Java String Compare
	     * 1.using equals() method
	     * 2.using "==" Operator
	     * 3.using compareTo() method
	     */
	    String s1 = "Komal";
	    String s2 = "Komal";
	    String s3 = "KOMAL";
	    String s5 = new String("Komal");
	    String s6 = new String("Komal");
	    String s7 = new String("KOMAL");
		String s8 = "";


		/**
		 * equals() and equalsIgnoreCase()
		 * returns true or false
		 * compare object values
		 */
//		System.out.println(s1.equals(s1));	//true
//		System.out.println(s1.equals(s2));	//true
//		System.out.println(s1.equals(s3));	//false
//		System.out.println(s1.equalsIgnoreCase(s3));	//true
//		System.out.println(s1.equals(null));	//false
//		System.out.println(s1.hashCode());	//72678740
//		System.out.println(s8.hashCode());	//0

//
//		System.out.println();
//		System.out.println(s1.equals(s5));
//		System.out.println(s5.equals(s6));	//true
//		System.out.println(s5.equals(s7));	//false
//		System.out.println(s5.equalsIgnoreCase(s7));	//true
//		System.out.println();
//

		/**
		 * using "==" Operator
		 * The == operator compares references not values.
		 */
//		System.out.println(s1==s2);	//true
//		System.out.println(s1==s3);	//false
//		System.out.println(s5==s6);	//false
//		System.out.println(s5.hashCode());
//		System.out.println(s6.hashCode());
//		System.out.println(s5==s7);
//		System.out.println();
//		String st = null;
//		System.out.println(st==null);	//true


		/**
		 * using compareTo() method: Two strings are compared lexicographically
		 * Compares two strings lexicographically. The comparison is based on the Unicode value of each character in the strings.
		 * The character sequence represented by this String object is
		 * compared lexicographically to the character sequence represented by the argument string.
		 * The result is a negative integer if this String object lexicographically precedes the argument string.
		 * The result is a positive integer if this String object lexicographically follows the argument string.
		 * The result is zero if the strings are equal;
		 * compareTo returns 0 exactly when the equals(Object) method would return true.
		 */
//		System.out.println(s1.compareTo(s2));	//0 - (equal)
//		System.out.println(s1.compareTo(s3));	//positive number - (s1>s2)
//		System.out.println(s1.compareToIgnoreCase(s3));	//0 - (equal)
//		System.out.println(s5.compareTo(s6));	//0 - (equal)
//		String ss1 = new String("");
//		System.out.println(ss1.compareTo(""));		//0(equal)
//		System.out.println(ss1.compareTo(null));	//Null pointer exception



		/**
		 * unicode values
		 */
//		for(int i=1; i<150; i++){
//			char ch = (char)i;
//			System.out.println(i+": "+ch);
//		}


		/**
		 * String concatination
		 * 1. By + (String concatenation) operator
		 * 2. By concat() method
		 */

//		String s1 = "Komal";
//		String ss1 = "Bollikolla";


		/**
		 * using "+" operator
		 * String s = "Komal"+" Bollikolla";
		 * compiler will change code to String s=(new StringBuilder()).append("Komal").append(" Bollikolla).toString();
		 * In Java, String concatenation is implemented through the StringBuilder (or StringBuffer) class,
		 * and it's append method. String concatenation operator produces a new String by appending
		 * the second operand onto the end of the first operand. The String concatenation operator can
		 * concatenate not only String but primitive values also.
		 */
//		String s2 = s1+" "+"Bollikolla";
//		String s3 = s1+" "+ss1;
//		System.out.println(s2);
//		System.out.println(s3);
//		System.out.println();

		/**
		 * using concat() method
		 */
//		String s4 = s1.concat(" "+"Bollikolla");
//		String s5 = s1.concat(ss1);
//		String s6 = s1.concat(" "+ss1);
//		System.out.println(s4);
//		System.out.println(s5);
//		System.out.println(s6);
//		System.out.println();


		/**
		 * SubString
		 * startIndex: inclusive
		 * endIndex: exclusive
		 * 1. public String substring(int startIndex)
		 * 2. public String substring(int startIndex, int endIndex)
		 */

//		String s="hello";
//		System.out.println(s.substring(0,2));
//
//		String s="SachinTendulkar";
//		System.out.println("Original String: " + s);
//		System.out.println("Substring starting from index 6: " +s.substring(6));	//Tendulkar
//		System.out.println("Substring starting from index 0 to 6: "+s.substring(0,6)); 		//Sachin


		/**
		 * Using String.split() method
		 * The split() method of String class can be used to extract a substring from a sentence.
		 * It accepts arguments in the form of a regular expression.
		 */
//		String text= new String("Hello, My name is Sachin");
//		/* Splits the sentence by the delimiter passed as an argument */
//		String[] sentences = text.split("\\s");	/* -- "\\s" will look for whitespace */
//		for (String s:
//			 sentences) {
//			System.out.println(s);
//
//		}
//		System.out.println(Arrays.toString(sentences));



		/**
		 * Java String toUpperCase() and toLowerCase() method
		 * The Java String toUpperCase() method converts this String into uppercase letter and
		 * String toLowerCase() method into lowercase letter.
		 */
//		String s="Sachin";
//		System.out.println(s);							//Sachin(no change in original)
//		System.out.println(s.hashCode());				// hashCode: -1826113608
//		System.out.println(s.toUpperCase());			//SACHIN
//		System.out.println(s.toUpperCase().hashCode());	// hashCode: -1856651368
//		System.out.println(s.toLowerCase());			//sachin
//		System.out.println(s.toLowerCase().hashCode());	// hashCode: -909980776

		/**
		 * Java String trim() method
		 * The String class trim() method eliminates white spaces before and after the String.
		 */
//		String s="  Sachin  ";
//		System.out.println(s);//  Sachin
//		System.out.println(s.trim());//Sachin

		/**
		 * Java String startsWith() and endsWith() method
		 * The method startsWith() checks whether the String starts with the letters passed as arguments and
		 * endsWith() method checks whether the
		 * String ends with the letters passed as arguments.
		 */
//		String s="Sachin";
//		System.out.println(s.startsWith("Sa"));		//true
//		System.out.println(s.endsWith("n"));		//true


		/**
		 * Java String charAt() Method
		 * The String class charAt() method returns a character at specified index.
		 */
//		String s="Sachin";
//		System.out.println(s.charAt(0));//S
//		System.out.println(s.charAt(3));//h


		/**
		 * Java String length() Method
		 * The String class length() method returns length of the specified String.
		 */
//		String s="Sachin";
//		System.out.println(s.length());//6


		/**
		 * Java String intern() Method
		 * A pool of strings, initially empty, is maintained privately by the class String.
		 * When the intern method is invoked, if the pool already contains a String equal to
		 * this String object as determined by the equals(Object) method, then the String from
		 * the pool is returned. Otherwise, this String object is added to the pool and a
		 * reference to this String object is returned.
		 */
//		String s=new String("Sachin");
//		String s2=s.intern();
//		System.out.println(s2);//Sachin


		/**
		 * Java String valueOf() Method
		 * The String class valueOf() method coverts given type such as
		 * int, long, float, double, boolean, char and char array into String.
		 */
//		int a=10;
//		String s=String.valueOf(a);
//		System.out.println(s+10);	//1010


		/**
		 * Java String replace() Method
		 * The String class replace() method replaces all occurrence of
		 * first sequence of character with second sequence of character.
		 */
//		String s1="Java is a programming language. Java is a platform. Java is an Island.";
//		String replaceString=s1.replace("Java","Kava");//replaces all occurrences of "Java" to "Kava"
//		System.out.println(replaceString);



//		String a = "komal";
//		String ab = a+"b";
//		String ab1 = "komalb";
//		String abc = "komalb";
//		System.out.println(ab1==abc);
////		System.out.println(ab1.hashCode());
////		System.out.println(abc.hashCode());
//
//		System.out.println();
////		System.out.println(ab.hashCode());
////		System.out.println(abc.hashCode());
//		System.out.println(ab==abc);

//		String s1 =3+2+"Komal";
//		String s2 =3+2+"Komal";
//		String s3 ="Komal"+3+2;
//		System.out.println(s3);
//		System.out.println(s1);
//		System.out.println(s2);
//		System.out.println(s1==s2);


		//display duplicate characters in the string
//		 String str="acdadcwertbb";
//		 for(int i=0; i<str.length(); i++){
//			 char ch = str.charAt(i);
//			 String subStr = str.substring(i+1);
//			 if(subStr.indexOf(ch)>=0) {
//				 System.out.println(ch);
//			 }
//		 }
//
//		System.out.println();
//
//		 //other Alternative to find duplicate characters in string
//		 for(int i=0; i<str.length(); i++){
//			char ch = str.charAt(i);
//			if(str.indexOf(ch,i+1)>=0)
//				System.out.println(ch);
//
//		}

		//removing duplicate characters
//		String str="acdadacwertbb";
//		StringBuffer str1 = new StringBuffer();
//		for(int i=0; i<str.length(); i++){
//			char ch = str.charAt(i);
//			String subStr = str.substring(i+1);
//			if(subStr.indexOf(ch)<0){
//				str1.append(ch);
//			}
//		}
//		System.out.println(str1);

}
	

}
