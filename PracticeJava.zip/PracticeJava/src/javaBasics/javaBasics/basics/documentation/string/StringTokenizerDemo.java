package javaBasics.javaBasics.basics.documentation.string;

import java.util.StringTokenizer;

public class StringTokenizerDemo {

    public static void main(String []args){

        StringTokenizer st = new StringTokenizer("My, name is komal");
        while(st.hasMoreTokens()){
            System.out.println(st.nextToken());
        }
        System.out.println();

        StringTokenizer st1 = new StringTokenizer("Hai Sanju, Today weather is so cool.");
        while(st1.hasMoreTokens()){
            System.out.println(st1.nextToken(","));
        }
        System.out.println();

        StringTokenizer st2 = new StringTokenizer("Hai Sanju, Today weather is so cool."," ");
        while(st2.hasMoreTokens()){
            System.out.println(st2.nextToken());
        }


    }
}
