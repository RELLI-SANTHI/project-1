package javaBasics.javaBasics.basics.documentation.string;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.Stream;

public class InterviewBit {

   // Function to display all permutations of the string str
   static void printallPermutns(String str, String str2)
   {
       // check if string is empty or null
       if (str.length() == 0) 
         {
           System.out.print(str2 + " ");
           return;
         }
      
       for (int i = 0; i < str.length(); i++) 
         { 
           // ith character of str
           char ch = str.charAt(i); 
           // Rest of the string after excluding
           // the ith character
           String str3 = str.substring(0, i) + str.substring(i + 1);
           // Recursive call
           printallPermutns(str3, str2 + ch);
        }
   } 
   // Driver code
   public static void main(String[] args)
   {
//       String s = "cat";
//       printallPermutns(s, "");
//       System.out.println();
//       System.out.println();
//       printallPermutns1(s, "");
//       Integer[] array = new Integer[]{1,23,4};
//       Stream<Integer> stream = Stream.of(array);
//       Stream<Integer> stream1 = Arrays.stream(array);

//       String str1 = "komal";
//       String str2 = "mokla";
//       char[] chArray = str1.toCharArray();
//       Arrays.sort(chArray);
//       System.out.println(String.valueOf(chArray));

       //Check for anagrams
//       String str1 = "komal";
//       String str2 = "mokla";
       Scanner sc = new Scanner(System.in);
       System.out.print("enter String 1 : ");
       String str1=sc.next();
       System.out.print("enter String 2 : ");
       String str2=sc.next();


        if(str1.length()==str2.length()) {
            char[] chArray1 = str1.toCharArray();
            char[] chArray2 = str2.toCharArray();
            Arrays.sort(chArray1);
            Arrays.sort(chArray2);
            if (Arrays.equals(chArray1, chArray2)) {
                System.out.println(str1 + " and " + str2 + " are anagrams");
            }
            else {
                System.out.println(str1 + " and " + str2 + " are not anagrams");
            }

        }
        else {
            System.out.println(str1 + " and " + str2 + " are not anagrams");
        }


   }



   static void printallPermutns1(String str, String str2){


       if(str.length()==0){
           System.out.println(str2+" ");
           return;
       }

       for(int i=0; i<str.length();i++){
           char ch = str.charAt(i);
           String str3 = str.substring(0,i)+str.substring(i+1);
           printallPermutns1(str3,str2+ch);
       }


   }
}