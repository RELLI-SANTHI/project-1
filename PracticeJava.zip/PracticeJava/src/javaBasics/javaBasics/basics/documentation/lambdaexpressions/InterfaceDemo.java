package javaBasics.javaBasics.basics.documentation.lambdaexpressions;

public interface InterfaceDemo {

    String name();

    int id();
}
