package javaBasics.javaBasics.basics.documentation.lambdaexpressions;

@FunctionalInterface
public interface FunctionalInterfaceDemo {

    int add(int a,int b);

}
