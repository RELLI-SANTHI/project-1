package javaBasics.javaBasics.basics.documentation.lambdaexpressions;

import javaBasics.employee.Employee;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class LambdaDemo {

    public static void main(String[] args) {


        /**
         * ************************_____________Lambda__Expressions___________********************************************
         * The Lambda expression is used to provide the implementation of an interface which has functional interface.
         * It saves a lot of code. In case of lambda expression,
         * we don't need to define the method again for providing the implementation.
         * Java lambda expression is treated as a function, so compiler does not create .class file.
         */

        /**
         * _________Functional Interface:____________________
         *
         * Lambda expression provides implementation of functional interface.
         * An interface which has only one abstract method is called functional interface.
         * Java provides an anotation @FunctionalInterface, which is used to declare an interface as functional interface.
         */

        /**
         * ____________Why use Lambda Expression?_______________
         * To provide the implementation of Functional interface.
         * Less coding.
         */

        /**
         * ____________Java Lambda Expression Syntax_________________
         *
         * (argument-list) -> {body}
         *
         * Java lambda expression is consisted of three components.
         * 1) Argument-list: It can be empty or non-empty as well.
         * 2) Arrow-token: It is used to link arguments-list and body of expression.
         * 3) Body: It contains expressions and statements for lambda expression.
         *
         * examples:
         * () -> {
         * //Body of no parameter lambda
         * }
         *
         * (p1,p2) -> {
         * //Body of multiple parameter lambda
         * }
         */

        //interface(one or more abstract methods) implementation using anonymous class
//        InterfaceDemo demo = new InterfaceDemo() {
//            @Override
//            public String name() {
//                return "Komal";
//            }
//
//            @Override
//            public int id() {
//                return 100;
//            }
//        };
//
//        System.out.println(demo.name());
//        System.out.println(demo.id());
//
//        //functional interface(only one abstract method) implementation using lambda
//        //use {} if body has 2 or more statements
//        FunctionalInterfaceDemo demo1 = (a,b) ->{return a+b;};
//
//        //If body has only one statement
//        FunctionalInterfaceDemo demo2 = (a,b) ->(a+b+100);
//
//        System.out.println(demo1.add(10,20));
//        System.out.println(demo2.add(10,20));
//
//        //method reference(Integer class has method sum())
//        FunctionalInterfaceDemo demo3 = Integer::sum;
//        System.out.println("100+200 = "+demo3.add(100,200));


//        //Lambda Expression in forEach method
//        List<Integer> list =new ArrayList<>(List.of(10,20,30));
//        //using lambda
//        list.forEach(n -> System.out.println(n));
//        //using method reference
//        list.forEach(System.out::println);

        //lambda expression for comparator
        //Comparator (Functional interface having only one abstract method)
//        List<Employee> employeeArrayList = new ArrayList<>();
//        employeeArrayList.add(new Employee(1,"Komal",21));
//        employeeArrayList.add(new Employee(2,"Ajay",23));
//        employeeArrayList.add(new Employee(3,"Sanju",21));
//        employeeArrayList.add(new Employee(10,"Vasanth",19));
//
//
//        Collections.sort(employeeArrayList, (emp1,emp2) ->(emp1.getAge()-emp2.getAge()));
//        System.out.println(employeeArrayList);

        String s = "abcd";
        char ch = 'a';
        System.out.println(Character.codePointAt(s,1));
        System.out.println(Character.codePointBefore(s,0));

//        System.out.println(String.valueOf('a')+String.valueOf('b'));
//        System.out.println('a'+'b');






    }
}
