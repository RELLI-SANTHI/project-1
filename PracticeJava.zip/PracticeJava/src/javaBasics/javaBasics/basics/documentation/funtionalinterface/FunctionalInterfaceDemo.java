package javaBasics.javaBasics.basics.documentation.funtionalinterface;
import java.util.function.*;
public class FunctionalInterfaceDemo {

    public static void main(String[] args) {

        /**
         * *************________Functional_Interface_________________*******************************************************
         * An Interface that contains exactly one abstract method is known as functional interface.
         * It can have any number of default, static methods but can contain only one abstract method.
         * It can also declare methods of object class.
         *
         * Functional Interface is also known as Single Abstract Method Interfaces or SAM Interfaces.
         * It is a new feature in Java, which helps to achieve functional programming approach.
         */

        /**
         * _________________Invalid Functional Interface:______________
         * A functional interface can extends another interface only when it does not have any abstract method.
         */

        /**
         * Java Predefined-Functional Interfaces
         * Java provides predefined functional interfaces to deal with functional programming by using lambda and method references.
         *
         * Interface	            Description
         * BiConsumer<T,U>----------It represents an operation that accepts two input arguments and returns no result.
         * Consumer<T>--------------It represents an operation that accepts a single argument and returns no result.
         * Function<T,R>------------It represents a function that accepts one argument and returns a result.
         * Predicate<T>-------------It represents a predicate (boolean-valued function) of one argument.
         * BiFunction<T,U,R>--------It represents a function that accepts two arguments and returns a result.
         * BinaryOperator<T>--------It represents an operation upon two operands of the same data type. It returns a result of the same type as the operands.
         * BiPredicate<T,U>---------It represents a predicate (boolean-valued function) of two arguments.
         * BooleanSupplier----------It represents a supplier of boolean-valued results.
         * DoubleBinaryOperator-----It represents an operation upon two double type operands and returns a double type value.
         * DoubleConsumer-----------It represents an operation that accepts a single double type argument and returns no result.
         * DoubleFunction<R>--------It represents a function that accepts a double type argument and produces a result.
         * DoublePredicate----------It represents a predicate (boolean-valued function) of one double type argument.
         * DoubleSupplier-----------It represents a supplier of double type results.
         * DoubleToIntFunction------It represents a function that accepts a double type argument and produces an int type result.
         * DoubleToLongFunction-----It represents a function that accepts a double type argument and produces a long type result.
         * DoubleUnaryOperator------It represents an operation on a single double type operand that produces a double type result.
         * IntBinaryOperator--------It represents an operation upon two int type operands and returns an int type result.
         * IntConsumer--------------It represents an operation that accepts a single integer argument and returns no result.
         * IntFunction<R>-----------It represents a function that accepts an integer argument and returns a result.
         * IntPredicate-------------It represents a predicate (boolean-valued function) of one integer argument.
         * IntSupplier--------------It represents a supplier of integer type.
         * IntToDoubleFunction------It represents a function that accepts an integer argument and returns a double.
         * IntToLongFunction--------It represents a function that accepts an integer argument and returns a long.
         * IntUnaryOperator---------It represents an operation on a single integer operand that produces an integer result.
         * LongBinaryOperator-------It represents an operation upon two long type operands and returns a long type result.
         * LongConsumer-------------It represents an operation that accepts a single long type argument and returns no result.
         * LongFunction<R>----------It represents a function that accepts a long type argument and returns a result.
         * LongPredicate------------It represents a predicate (boolean-valued function) of one long type argument.
         * LongSupplier-------------It represents a supplier of long type results.
         * LongToDoubleFunction-----It represents a function that accepts a long type argument and returns a result of double type.
         * LongToIntFunction--------It represents a function that accepts a long type argument and returns an integer result.
         * LongUnaryOperator--------It represents an operation on a single long type operand that returns a long type result.
         * ObjDoubleConsumer<T>-----It represents an operation that accepts an object and a double argument, and returns no result.
         * ObjIntConsumer<T>--------It represents an operation that accepts an object and an integer argument. It does not return result.
         * ObjLongConsumer<T>-------It represents an operation that accepts an object and a long argument, it returns no result.
         * Supplier<T>--------------It represents a supplier of results.
         * ToDoubleBiFunction<T,U>--It represents a function that accepts two arguments and produces a double type result.
         * ToDoubleFunction<T>------It represents a function that returns a double type result.
         * ToIntBiFunction<T,U>-----It represents a function that accepts two arguments and returns an integer.
         * ToIntFunction<T>---------It represents a function that returns an integer.
         * ToLongBiFunction<T,U>----It represents a function that accepts two arguments and returns a result of long type.
         * ToLongFunction<T>--------It represents a function that returns a result of long type.
         * UnaryOperator<T>---------It represents an operation on a single operand that returns  a result of the same type as its operand.
         *
         */


//        //Consumer
//        Consumer<Integer> c = (a) -> System.out.println(++a);
//        c.accept(10);
//        Consumer<Integer> c1 = System.out::println;
//        c1.accept(10);
//
//        //BiConsumer
//        BiConsumer<Integer,Integer> bc = (a,b) -> System.out.println(a+b);
//        bc.accept(10,20);
//
        //Supplier
        Supplier<String> s = () -> ("Komal");
        System.out.println(s.get());
//
//        //Function
//        Function<Integer,Integer> f = (a) -> (a+100);
//        System.out.println(f.apply(10));
//
//
//
//        //BiFunction
//        BiFunction<Integer,Integer,Integer> bf = (a,b) -> (a+b+100);
//        System.out.println(bf.apply(10,20));
//
//
//
//        //Predicate
//        Predicate<Integer> p =(a) -> (a>10);
//        System.out.println(p.test(8));
//
//
//
//        //BiPredicate
//        BiPredicate<Integer,Integer> bp = (a,b) -> (a+b>100);
//        System.out.println(bp.test(45,45));
//
//
//        //UnaryOperator
//        UnaryOperator<Integer> uop = (a) -> (a+100);
//        System.out.println(uop.apply(50));
//
//        //BianaryOperator
//        BinaryOperator<Integer> bop = (a,b) -> ((a+b)/10);
//        System.out.println(bop.apply(100,200));


















    }
}
