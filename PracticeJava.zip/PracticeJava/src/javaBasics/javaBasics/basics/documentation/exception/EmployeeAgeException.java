package javaBasics.javaBasics.basics.documentation.exception;

class EmployeeAgeException extends RuntimeException {


    public EmployeeAgeException() {
        super("age<18");
    }

    public EmployeeAgeException(String str) {

        super(str);
    }
}
