package javaBasics.javaBasics.basics.documentation.exception;

import javaBasics.employee.Employee;
import javaBasics.javaBasics.basics.documentation.exception.EmployeeAgeException;

public class exceptionsDemo {
    public static void main(String[] args){

        Employee emp1 = new Employee(1,"komal",17);

        try{
            if(emp1.getAge()<18)
                throw new EmployeeAgeException();
        }catch(EmployeeAgeException exe){
            System.out.println(exe.getMessage());
            //System.out.println(exe);
        }
        try{
            if(emp1.getAge()<18)
                throw new EmployeeAgeException("age less that 18");
        }catch(EmployeeAgeException exe){
            System.out.println(exe.getMessage());
        }
        System.out.println("age: "+emp1.getAge());

    }
}



