package javaBasics.javaBasics.basics.documentation.methodreference;

import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;

public class MethodReferenceDemo {


    static void saySomething(){
        System.out.println("Hello, Good Morning...This is method reference....reference to a static method");
    }

    static void sum(Integer a,Integer b){
        System.out.println("Sum : "+a+b);
    }

    void saying(){
        System.out.println("Hello, Good Morning ....This is method reference ....reference to a instance method");
    }
    void sub(Integer a,Integer b){
        System.out.println("sub : "+ (a-b));
    }


    public MethodReferenceDemo() {
        System.out.println("In MethodReferenceDemo constructor");
    }

    public static void main(String[] args) {

        /**
         * **************________Method_Reference____________*************************************************************
         * Java provides a new feature called method reference in Java 8.
         * Method reference is used to refer method of functional interface.
         * It is compact and easy form of lambda expression.
         *
         * Each time when you are using lambda expression to just referring a method, you can
         * replace your lambda expression with method reference.
         */

        /**
         * Types of Method References
         * 1.Reference to a static method--------[ContainingClass::staticMethodName]
         * 2.Reference to an instance method-----[ContainingObject::instanceMethodName]
         * 3.Reference to a constructor----------[ClassName::new]
         */


        /**
         * 1) Reference to a Static Method
         * You can refer to static method defined in the class.
         * Following is the syntax and example which describe the process of referring static method in Java.
         *
         * Syntax:
         * ContainingClass::staticMethodName
         */
        //using lambda
//        Sayable s  = () ->System.out.println("hai lambda");
//        s.say();
//
//        //using method reference
//        Sayable s1 = MethodReferenceDemo::saySomething;
//        s1.say();
//
//        //Method reference for Bi consumer
//        BiConsumer<Integer,Integer> bc = MethodReferenceDemo::sum;
//        bc.accept(10,20);

        /**
         * 2) Reference to an Instance Method
         * like static methods, you can refer instance methods also.
         * You can refer instance methods or non-static methods by class object and anonymous object.
         *
         * Syntax:
         * containingObject::instanceMethodName
         */
        //using new object
//        MethodReferenceDemo mr = new MethodReferenceDemo();
//        Sayable s3 = mr::saying;
//        s3.say();
//
//        //using anonymous object
//        Sayable s4 = (new MethodReferenceDemo())::saying;
//        s4.say();
//
//        //Method reference for Bi consumer
//        BiConsumer<Integer,Integer> bc1 = new MethodReferenceDemo()::sub;
//        bc1.accept(20,19);


        /**
         * 3) Reference to a Constructor
         * You can refer a constructor by using the new keyword.
         * Here, we are referring constructor with the help of functional interface.
         *
         * Syntax
         * ClassName::new
         */
//        Sayable s5 = MethodReferenceDemo::new;
//        s5.say();

















    }

}
