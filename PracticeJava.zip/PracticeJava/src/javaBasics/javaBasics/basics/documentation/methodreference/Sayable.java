package javaBasics.javaBasics.basics.documentation.methodreference;

public interface Sayable {

    void say();
}
