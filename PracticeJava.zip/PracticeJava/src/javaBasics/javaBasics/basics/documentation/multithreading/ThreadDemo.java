package javaBasics.javaBasics.basics.documentation.multithreading;

public class ThreadDemo {
    public static void main(String[] args) {
        A obj1 = new A();
        B obj2 = new B();

        obj1.start();
        obj2.start();

    }
}

class A extends Thread{
    @Override
    public void run(){
        for (int i=0; i<10; i++) {
            System.out.println("Class A");
            try {
                sleep(15);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}

class B extends Thread{
    @Override
    public void run(){
        for (int i=0; i<10; i++) {
            System.out.println("Class B");
            try {
                sleep(15);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        }

}
