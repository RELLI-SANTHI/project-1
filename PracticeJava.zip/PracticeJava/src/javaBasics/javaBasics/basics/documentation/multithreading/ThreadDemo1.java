package javaBasics.javaBasics.basics.documentation.multithreading;

import static java.lang.Thread.sleep;

public class ThreadDemo1 {
    public static void main(String[] args) {
        //anonymous class
       Runnable obj1 = new Runnable() {
           @Override
           public void run() {
               for (int i=0; i<10; i++) {
                   System.out.println("Class t1");
                   try {
                       sleep(15);
                   } catch (InterruptedException e) {
                       throw new RuntimeException(e);
                   }
               }
           }
           };

       Runnable obj2 = new Runnable() {
            @Override
            public void run() {
                for (int i=0; i<10; i++) {
                    System.out.println("Class t2");
                    try {
                        sleep(15);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
            };
        Thread t1 = new Thread(obj1);
        Thread t2 = new Thread(obj2);

        // t1.start();
        //t2.start();

        //using Lambda expression
        Runnable obj3 = ()->{
            for (int i=0; i<10; i++) {
                System.out.println("Class t3");
                try {
                    sleep(15);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        };
        Runnable obj4 = ()->{
            for (int i=0; i<10; i++) {
                System.out.println("Class t4");
                try {
                    sleep(15);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        };
        Thread t3 = new Thread(obj3);
        Thread t4 = new Thread(obj4);

        t3.start();
        t4.start();



    }
}

