package javaBasics.javaBasics.basics.documentation.collections;

import java.util.ArrayDeque;
import java.util.Queue;

public class ArrayDequeDemo {

    public static void main(String[] args) {

        ArrayDeque<String> q = new ArrayDeque<>();
        q.offer("Komal");
        q.offer("Sanju");
        q.offer("Vasanth");
        q.offer("Ajay");
        q.offer("Akhil");

        System.out.println(q);

        q.offerFirst("ZZZZ");
        q.offerLast("AAAA");
        System.out.println(q);

        System.out.println();

        System.out.println(q.pollFirst());
        System.out.println(q.pollLast());
        System.out.println(q);

        System.out.println();

        System.out.println(q.peekFirst());
        System.out.println(q.peekLast());
        System.out.println(q);


    }
}
