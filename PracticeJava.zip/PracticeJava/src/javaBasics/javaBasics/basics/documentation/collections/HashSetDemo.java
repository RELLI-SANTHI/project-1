package javaBasics.javaBasics.basics.documentation.collections;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class HashSetDemo {

    public static void main(String[] args) {

        /**
         * ********************__________HashSet_____________***************************************************************
         * Java HashSet class is used to create a collection that uses a hash table for storage.
         * It inherits the AbstractSet class and implements Set interface.
         * HashSet stores the elements by using a mechanism called hashing.
         * HashSet contains unique elements only.
         * HashSet allows one null value.
         * HashSet class is non synchronized.
         * HashSet doesn't maintain the insertion order. Here, elements are inserted on the basis of their hashcode.
         * HashSet is the best approach for search operations.
         * The initial default capacity of HashSet is 16, and the load factor is 0.75
         */

        /**
         * Constructors of Java HashSet class
         *
         * SNo.	Constructor                         	    Description
         * 1)	HashSet()-----------------------------------It is used to construct a default HashSet.
         * 2)	HashSet(int capacity)-----------------------It is used to initialize the capacity of the hash set to the given integer value capacity. The capacity grows automatically as elements are added to the HashSet.
         * 3)	HashSet(int capacity, float loadFactor)-----It is used to initialize the capacity of the hash set to the given integer value capacity and the specified load factor.
         * 4)	HashSet(Collection<? extends E> c)----------It is used to initialize the hash set by using the elements of the collection c.
         */

        /**
         * Methods of Java HashSet class
         *
         * SN	Modifier & Type	Method	            Description
         * 1)	boolean	add(E e)--------------------It is used to add the specified element to this set if it is not already present.
         * 2)	void	clear()---------------------It is used to remove all of the elements from the set.
         * 3)	object	clone()---------------------It is used to return a shallow copy of this HashSet instance: the elements themselves are not cloned.
         * 4)	boolean	contains(Object o)----------It is used to return true if this set contains the specified element.
         * 5)	boolean	isEmpty()-------------------It is used to return true if this set contains no elements.
         * 6)	Iterator<E>	iterator()--------------It is used to return an iterator over the elements in this set.
         * 7)	boolean	remove(Object o)------------It is used to remove the specified element from this set if it is present.
         * 8)	int	size()--------------------------It is used to return the number of elements in the set.
         * 9)	Spliterator<E>	spliterator()-------It is used to create a late-binding and fail-fast Spliterator over the elements in the set.
         */


        HashSet<Integer> s1 = new HashSet<>();
        s1.add(10);
        s1.add(22);
        s1.add(21);
        s1.add(56);
        s1.add(45);
        s1.add(78);
        s1.add(null);
        s1.forEach(System.out::println);
        System.out.println();


        Set<Integer> s2 = new HashSet<>(Set.of(56,45));

        System.out.println(s1); //[21, 22, 56, 45, 78]

        System.out.println(s1.size());   //5

        //not allow duplicate elements
        s1.add(56);
        System.out.println(s1); //[21, 22, 56, 45, 78]

        System.out.println(s1.hashCode());  //222

        s1.remove(56);
        System.out.println(s1); //[21, 22, 45, 78]


        System.out.println(s1.contains(22));    //true


        Iterator<Integer> itr = s1.iterator();
        while(itr.hasNext()){
            System.out.println(itr.next());
        }


        s1.removeAll(s2);
        System.out.println(s1);     //[21, 22, 78]




        s1.clear();
        System.out.println(s1);   //[]
        System.out.println(s1.isEmpty());   //true















    }
}
