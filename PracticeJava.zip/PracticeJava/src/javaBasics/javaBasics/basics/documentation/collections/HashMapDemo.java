package javaBasics.javaBasics.basics.documentation.collections;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class HashMapDemo extends Object{
    public static void main(String[] args) {

        HashMap<Integer, String> map = new HashMap<>();
        map.put(1,"Komal");
        map.put(2,"Sanju");
        map.put(4,"Bhavana");
        map.put(3,"Ajay");
        map.put(4,"BHAVANA");




//        map.putIfAbsent(4,"Bhavana");
//        map.putIfAbsent(5,"Bhavana");
////        map.put(null,null);
//        System.out.println(map);

//        Set<Integer> keySet = map.keySet();
//        System.out.println("Key set: "+keySet);
//        System.out.println("value for key 1: "+map.get(1));
////
//        Set<Map.Entry<Integer,String >> m =  map.entrySet();
//        System.out.println(m);
//
//        Iterator<Map.Entry<Integer,String>> itr = m.iterator();
//        while(itr.hasNext()){
//            System.out.println(itr.next());
//        }
//        System.out.println();
//        m.forEach((e)-> System.out.println("Key: "+e.getKey()+" Value: "+e.getValue()));

//        map.forEach((k,v)-> System.out.println("key : "+k+" value : "+v));
//
//        for(Map.Entry<Integer,String> entry : map.entrySet() ){
//            System.out.println("Key: "+entry.getKey()+", Value: "+entry.getValue());
//        }
//        System.out.println();
//
//        map.forEach((k,v) -> System.out.println("key: "+k+", Value: "+v));


//        map.replaceAll((k,v) -> "Ajay");
//        System.out.println(map);

//
//        int a = 242323 & 25;
//        System.out.println(a);


    }
}
