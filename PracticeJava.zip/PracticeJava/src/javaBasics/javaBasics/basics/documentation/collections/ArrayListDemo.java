package javaBasics.javaBasics.basics.documentation.collections;

import java.util.*;
import java.util.function.UnaryOperator;

public class ArrayListDemo {

    public static void main(String[] args){


        /**
         * ************___________ArrayList_____________*****************************************************************
         * Java ArrayList class uses a dynamic array for storing the elements. It is like an array, but there is no size limit
         * Java ArrayList class can contain duplicate elements.
         * Java ArrayList class maintains insertion order.
         * Java ArrayList class is non synchronized.
         * Java ArrayList allows random access because the array works on an index basis.
         *
         * In ArrayList, manipulation is a little bit slower than the LinkedList in Java because a lot
         * of shifting needs to occur if any element is removed from the array list.
         *
         * We can not create an array list of the primitive types, such as int, float, char, etc.
         * It is required to use the required wrapper class in such cases
         */


        /**
         * Constructors of ArrayList
         * Constructor	                              Description
         * ArrayList()	                              It is used to build an empty array list.
         * ArrayList(Collection<? extends E> c)	      It is used to build an array list that is initialized with the elements of the collection c.
         * ArrayList(int capacity)	                  It is used to build an array list that has the specified initial capacity.
         */


        /**
         * Methods of ArrayList
         * Method	                                                Description
         * void add(int index, E element)---------------------------It is used to insert the specified element at the specified position in a list.
         * boolean add(E e)-----------------------------------------It is used to append the specified element at the end of a list.
         * boolean addAll(Collection<? extends E> c)----------------It is used to append all of the elements in the specified collection to the end of this list, in the order that they are returned by the specified collection's iterator.
         * boolean addAll(int index, Collection<? extends E> c)-----It is used to append all the elements in the specified collection, starting at the specified position of the list.
         * void clear()---------------------------------------------It is used to remove all of the elements from this list.
         * void ensureCapacity(int requiredCapacity)----------------It is used to enhance the capacity of an ArrayList instance.
         * E get(int index)-----------------------------------------It is used to fetch the element from the particular position of the list.
         * boolean isEmpty()----------------------------------------It returns true if the list is empty, otherwise false.
         * **************Iterator()*************************
         * **************listIterator()*********************
         * int lastIndexOf(Object o)--------------------------------It is used to return the index in this list of the last occurrence of the specified element, or -1 if the list does not contain this element.
         * Object[] toArray()---------------------------------------It is used to return an array containing all of the elements in this list in the correct order.
         * <T> T[] toArray(T[] a)-----------------------------------It is used to return an array containing all of the elements in this list in the correct order.
         * Object clone()-------------------------------------------It is used to return a shallow copy of an ArrayList.
         * boolean contains(Object o)-------------------------------It returns true if the list contains the specified element.
         * int indexOf(Object o)------------------------------------It is used to return the index in this list of the first occurrence of the specified element, or -1 if the List does not contain this element.
         * E remove(int index)--------------------------------------It is used to remove the element present at the specified position in the list.
         * boolean remove(Object o)---------------------------------It is used to remove the first occurrence of the specified element.
         * boolean removeAll(Collection<?> c)-----------------------It is used to remove all the elements from the list.
         * boolean removeIf(Predicate<? super E> filter)------------It is used to remove all the elements from the list that satisfies the given predicate.
         * protected void removeRange(int fromIndex, int toIndex)---It is used to remove all the elements lies within the given range.
         * void replaceAll(UnaryOperator<E> operator)---------------It is used to replace all the elements from the list with the specified element.
         * void retainAll(Collection<?> c)--------------------------It is used to retain all the elements in the list that are present in the specified collection.
         * E set(int index, E element)------------------------------It is used to replace the specified element in the list, present at the specified position.
         * void sort(Comparator<? super E> c)-----------------------It is used to sort the elements of the list on the basis of the specified comparator.
         * Spliterator<E> spliterator()-----------------------------It is used to create a spliterator over the elements in a list.
         * List<E> subList(int fromIndex, int toIndex)--------------It is used to fetch all the elements that lies within the given range.
         * int size()-----------------------------------------------It is used to return the number of elements present in the list.
         * void trimToSize()----------------------------------------It is used to trim the capacity of this ArrayList instance to be the list's current size.
         */

//        ArrayList<Integer> arrayList = new ArrayList<>();
//        arrayList.add(11);
//        arrayList.add(21);
//        arrayList.add(10);
//        arrayList.add(17);
//        arrayList.add(7);
//        arrayList.add(32);
//        System.out.println(arrayList);
//
//        Collections.sort(arrayList);
//        System.out.println(arrayList);
//
//        arrayList.sort(Collections.reverseOrder());
//        System.out.println(arrayList);
//
//        arrayList.sort(Comparator.reverseOrder());
//        System.out.println(arrayList);

        /**
         * Heterogeneous Elements in list
         */
//        List<Object> list1 = new ArrayList<>();
//        list1.add(12);
//        list1.add("Komal");
//        System.out.println(list1);




        /**
         * removeAll(unaryOperator)
         */
//        List<String> list = new ArrayList<>();
//        list.add("Sanju");
//        list.add("Komal");
//        System.out.println(list);   //[12, Komal]
//        System.out.println(list.hashCode());    //72680073
//        list.replaceAll( (e)->e.toUpperCase());
//        list.replaceAll(String::toUpperCase);
//        System.out.println(list);
//        UnaryOperator<String> op1= new UnaryOperator<>() {
//
//            @Override
//            public String apply(String o) {
//
//                return o.toUpperCase();
//            }
//        };
//        UnaryOperator<String> op2 =(s) -> (s.toUpperCase());
//        list.replaceAll(op2);
//        System.out.println(list);


        /**
         * void add(int index, E element)
         * boolean add(E e)
         * int size()
         */

//        List<Integer> l1 = new ArrayList<>();
//        l1.add(100);
//        l1.add(42);
//        l1.add(11);
//        l1.add(23);
//        l1.add(98);
//        l1.add(65);
//        l1.add(4,44);
//        System.out.println(l1);     //[100, 42, 11, 23, 44, 98, 65]
//        l1.add(3,33);
//        System.out.println(l1);     //[100, 42, 11, 33, 23, 44, 98, 65]
//        System.out.println(l1.size());


        /**
         * boolean addAll(Collection<? extends E> c)
         * boolean addAll(int index, Collection<? extends E> c)
         * void clear()
         * E get(int index)
         * boolean isEmpty()
         * int lastIndexOf(Object o)
         * Object[] toArray()
         * <T> T[] toArray(T[] a)
         */
//        List<Integer> l2 = new ArrayList<>(List.of(11,32,41));
//        List<Integer> l3 = new ArrayList<>(List.of(23,42,77));
//        //l3.addAll(l2);
//        //System.out.println(l3);
//
//        //addAll()
//        l3.addAll(1,l2);
//        System.out.println(l3); //[23, 11, 32, 41, 42, 77]
//
//        //get()
//        System.out.println(l3.get(2));   //32
//
//        //clear()
//        l3.clear();
//        System.out.println(l3);  //[]
//
//        //isEmpty()
//        System.out.println(l3.isEmpty());  //true
//
//
//        //lastIndexOf()
//        List<Integer> l4 = new ArrayList<>(List.of(22,11,40,22,11));
//        System.out.println(l4.lastIndexOf(11));     //4
//        System.out.println(l4.lastIndexOf(22));     //3
//
//        //toArray()
//        Object[] integers = l4.toArray();
//        System.out.println(Arrays.toString(integers));
//
//        //toArray
//        Integer[] integers1 = new Integer[l4.size()];
//        integers1 = l4.toArray(integers1);
//        System.out.println(Arrays.toString(integers1));
//        List<Integer> l3 = new ArrayList<>(List.of(11,32,41));
//        Integer[] array = l3.toArray(new Integer[l3.size()]);
//        System.out.println(Arrays.toString(array));


        /**
         * boolean contains(Object o)
         * int indexOf(Object o)
         * E remove(int index)
         * boolean removeAll(Collection<?> c)
         */
//        List<Integer> l5 = new ArrayList<>(List.of(76,65,83,34,23,91,12));
//
//        //contains()
//        System.out.println(l5.contains(44));
//
//        //indexOf()
//        System.out.println(l5.indexOf(76));
//
//        //remove()
//        Integer i =l5.remove(3);
//        System.out.println(l5.remove(1));
////        System.out.println(l5.remove(76));
//        System.out.println(l5);
//
//        //removeAll
////        l5.removeAll(l5);
////        System.out.println(l5);

        /**
         * forEach() method with method reference or lambda
         * forEach loop
         * Iterator
         * ListIterator
         */
//        List<String> stringlist = new ArrayList<>(List.of("Komal","Sanju","Arut","Ajay","Bhavana","Adithi"));
//        //using forEach() method
//        stringlist.forEach((e)-> System.out.println(e+100));
//        stringlist.forEach(System.out::println);
//        //foreach loop
//        for(String s : stringlist){
//            System.out.println(s);
//        }
//        System.out.println();
//
//        //iterator()
//        Iterator<String> itr = stringlist.iterator();
//        while(itr.hasNext()){
//            System.out.println(itr.next());
//        }
//        System.out.println();
//
//        //ListIterator
//        ListIterator<String> itr1 = stringlist.listIterator();
//        while(itr1.hasNext()){
////            System.out.println(itr1.next());
//
//            String value = itr1.next();
//            if(value.equals("Komal"))
//
//                itr1.set("KOMAL");
//
//
//        }
//        System.out.println(stringlist);
//

        /**
         * reversing list
         */
//        //printing in reverse order using ListIterator
//        ListIterator itr2 = stringlist.listIterator();
//        while(itr1.hasPrevious()){
//            System.out.println(itr1.previous());
//        }
//
//        //using Collections.reverse()
//        List<String> stringlist1 = new ArrayList<>(List.of("Komal","Sanju","Arut","Ajay","Bhavana","Adithi"));
//        stringlist1.sort(Collections.reverseOrder());
//        stringlist1.forEach(System.out::println);
//        Collections.reverse(stringlist1);
//        System.out.println(stringlist1);

//        //using sort method
//        List<String> stringlist2 = new ArrayList<>(List.of("Komal","Sanju","Arut","Ajay","Bhavana","Adithi"));
//        stringlist2.sort((a,b)->-a.compareTo(b));
//        stringlist2.forEach(System.out::println);
//        stringlist2.sort(Comparator.reverseOrder());
//        stringlist2.forEach(System.out::println);

        /**
         * sorting
         */
        //using Collections.sort()
//        List<String> stringlist2 = new ArrayList<>(List.of("Komal","Sanju","Arut","Ajay","Bhavana","Adithi"));
//        Collections.sort(stringlist2);
//        System.out.println(stringlist2);
//        stringlist2.sort((a,b)->a.compareTo(b));
//        stringlist2.sort(String::compareTo);
//        System.out.println(stringlist2);


        /**
         * T[] toArray(T[] a)
         */
//        List<Integer> list = new ArrayList<>(List.of(1,2));
//        Integer[] listArray = new Integer[list.size()];
//        listArray = list.toArray(listArray);
//        System.out.println(Arrays.toString(listArray));

        /**
         * List<E> subList(int fromIndex, int toIndex)
         * fromIndex is inclusive and toIndex is exclusive
         */
//        List<Integer> list = new ArrayList<>(List.of(1,4,3,8,5));
//        List<Integer> subList = list.subList(2,4);
//        System.out.println(subList);
    }
}
