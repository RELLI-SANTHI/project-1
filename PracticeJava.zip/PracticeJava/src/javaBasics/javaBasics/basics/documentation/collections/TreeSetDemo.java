package javaBasics.javaBasics.basics.documentation.collections;

public class TreeSetDemo {

    public static void main(String[] args) {

        /**
         * **************__________TreeSet________________*******************************************************************
         * Java TreeSet class implements the Set interface that uses a tree for storage.
         * It inherits AbstractSet class and implements the NavigableSet interface.
         * The objects of the TreeSet class are stored in ascending order.
         *
         * Java TreeSet class contains unique elements only like HashSet.
         * Java TreeSet class access and retrieval times are quiet fast.
         * Java TreeSet class doesn't allow null element.
         * Java TreeSet class is non synchronized.
         * Java TreeSet class maintains ascending order.
         *
         * The TreeSet can only allow those generic types that are comparable.
         * For example The Comparable interface is being implemented by the StringBuffer class.
         */
    }
}
