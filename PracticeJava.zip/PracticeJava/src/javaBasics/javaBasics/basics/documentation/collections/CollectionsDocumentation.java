package javaBasics.javaBasics.basics.documentation.collections;

public class CollectionsDocumentation {

    /**
     * *************_______Collection_______*******************************************************
     * The Collection in Java is a framework that provides an architecture to store and manipulate the group of objects.
     * A Collection represents a single unit of objects, i.e., a group.
     *
     *                                                  iterable(Interface)
     *                                                          |
     *                                                 Collection(Interface)
     *           _______________________________________________|_______________________________________________
     *          |                                               |                                              |
     *     List(Interface)                               Queue(Interface)                                  Set(Interface)
     *          |                                           |       |                                        |      |
     *          |                                           |       |<-----PriorityQueue(Class)              |      |<-----HashSet(Class)
     *          |<-----ArrayList(Class)                     |                                                |      |
     *          |                                      Deque(Interface)                                      |      |<-----LinkedHashSet(Class)
     *          |                                           |                                                |
     *          |<-----LinkedList(Class)------------------->|                                        SortedSet(Interface)
     *          |                                           |<-----ArrayDeque(Class)                         |
     *          |                                                                                            |
     *          |<-----Vector(Class)                                                                         |<-----TreeSet(Class)
     *                      |
     *                      |<-----Stack(Class)
     *
     *
     *
     */
}
