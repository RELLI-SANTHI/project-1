package javaBasics.javaBasics.basics.documentation.collections;

import java.util.Comparator;
import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Queue;

public class PriorityQueueDemo {

    public static void main(String[] args) {

        //prioritize the first element based on sorting
//        Queue<String> q = new PriorityQueue<>();
//
//        q.offer("komal");
//        q.offer("sanju");
//        q.offer("arut");
//        q.offer("arya");
//        q.offer("arjun");
//        q.offer("bala");
//        q.offer("rohit");
//        q.offer("vasanth");
//        q.offer("chandu");
//        q.offer("ram");
//
//
//
//
//        System.out.println(q);
//        System.out.println(q.poll());
//        System.out.println(q);
//        System.out.println(q.poll());
//        System.out.println();
//        Iterator<String> itr = q.iterator();
//
//        for(String s: q){
//            System.out.println(s);
//        }
//
//        while(itr.hasNext()){
//            System.out.println(itr.next());
//        }




//        PriorityQueue<Integer> q1 = new PriorityQueue<>();
//
//        q1.offer(82);
//        q1.offer(23);
//        q1.offer(11);
//        q1.offer(43);
//        q1.offer(10);
//        System.out.println(q1);
//
//        System.out.println(q1.poll());
//        System.out.println(q1);
//
//        System.out.println(q1.peek());
//        System.out.println(q1);
//
//        System.out.println(q1.poll());
//        System.out.println(q1);
//
//        System.out.println(q1.poll());
//        System.out.println(q1);
    }
}
