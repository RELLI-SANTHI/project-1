package javaBasics.javaBasics.basics.documentation.collections;

public class LinkedHashSetDemo {

    public static void main(String[] args) {
        /**
         * ***************__________LinkedHashSet____________************************************************************
         * Java LinkedHashSet class is a Hashtable and Linked list implementation of the Set interface.
         * It inherits the HashSet class and implements the Set interface.
         * Java LinkedHashSet class contains unique elements only like HashSet.
         * Java LinkedHashSet class provides all optional set operations and permits null elements.
         * Java LinkedHashSet class is non-synchronized.
         * Java LinkedHashSet class maintains insertion order.
         */

        /**
         * Constructors of Java LinkedHashSet Class
         * Constructor	                                        Description
         * HashSet()--------------------------------------------It is used to construct a default HashSet.
         * HashSet(Collection c)--------------------------------It is used to initialize the hash set by using the elements of the collection c.
         * LinkedHashSet(int capacity)--------------------------It is used to initialize the capacity of the linked hash set to the given integer value capacity.
         * LinkedHashSet(int capacity, float fillRatio)---------It is used to initialize both the capacity and the fill ratio (also called load capacity) of the hash set from its argument.
         */

        /**
         *
         */
    }
}
