package javaBasics.employee;

public class EmployeeMain {

    public static  void main(String[] args){
//        Employee emp1 = new Employee(1,"Komal");
//        Employee emp2 = new Employee(2,"Sanju");
//        Employee emp3 = new Employee();
//        Employee emp4 = new Employee(1,"Komal");
//        Employee emp5 = emp1;   //both will refer to same location
//        Employee emp6 = null;

//        System.out.println(emp1.equals(emp5));  //true
//        System.out.println(emp1.equals(emp1));  //true
//        System.out.println(emp1.equals(null));  //false
//        System.out.println(emp6.equals(null));  // run time error(null value cannot invoke equals method)
//        System.out.println(emp1.equals(emp2));  //false
//        System.out.println(emp1);
//        System.out.println(emp1.hashCode());

//        try {
//            Employee emp7 = (Employee) emp1.clone();
////            System.out.println(emp7.hashCode());
//        } catch (CloneNotSupportedException e) {
//            throw new RuntimeException(e);
//        }



    }
}
