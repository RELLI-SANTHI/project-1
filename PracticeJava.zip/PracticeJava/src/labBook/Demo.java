package labBook;

import java.util.*;


public class Demo {
	public static void main(String args[])
	{
//		int x=0;
//		int y=1;
//		int z;
//		System.out.print("Enter a number :");
//		Scanner sc = new Scanner(System.in);
//		int i = sc.nextInt();
//		
//		System.out.println(i);
//		System.out.println(y);
//		
//		for(int i=2;i<7;i++)
//		{
//			z=x+y;
//			System.out.println(z);
//			x=y;
//			y=z;
//		}
		
		ArrayList<Integer> arr = new ArrayList<>();
		arr.add(21);
		arr.add(65);
		arr.add(96);
		arr.add(43);
		
		//arr.add(null);
//		Collections.sort(arr);
//		System.out.println(arr);
//		
//		System.out.println(Collections.binarySearch(arr, 50));
//		arr.replaceAll( i -> 10);
//		Collections.fill(arr, 10);
		
//		System.out.println(arr);
//		arr.add(23);
//		System.out.println(arr);
		
//		ArrayList<Integer> arr1 = new ArrayList<>(10);
//		Collections.fill(arr1, 10);
//		System.out.println(arr1);
		
		
		
		
		
		
//		for(int i=0;i<arr.size();i++)
//		{
//			System.out.println(arr.get(i));
//		}
//		
//		System.out.println();
//		
//		for(Integer i : arr) {
//			System.out.println(i);
//		}
//		
//		System.out.println(arr.contains(100));
//		
//		//arr.add(null);
//		System.out.println();
//		Iterator<Integer> itr =arr.iterator();
//		
//		while(itr.hasNext())
//		{
//			System.out.println(itr.next());
//		}
//		System.out.println();
//		Collections.sort(arr);
//		ArrayList<Integer> arr2 = new ArrayList<>(arr);
//		arr2.add(1000);
//		arr2.forEach(i->System.out.println(i));
		
		
//		Queue<Integer> q = new PriorityQueue<>();
//		q.offer(25);
//		q.offer(22);
//		q.offer(99);
//		q.offer(11);
//		System.out.println(q);
//		System.out.println(q.peek());
//		System.out.println(q.poll());
//		System.out.println(q);
//	
//		System.out.println(q.element());
		

//		Deque<Integer> d = new ArrayDeque<>();
//		d.addAll(q);
//		System.out.println(d);
//		d.offerFirst(10);
//		d.offerLast(20);
//		System.out.println(d);
//		System.out.println(d.peekLast());
//		System.out.println(d.peekFirst());
//		System.out.println();
//		System.out.println(d.poll());
//		System.out.println(d.peekFirst());
//		System.out.println(d.pollFirst());
//		System.out.println(d.pollLast());
		
//		Set<String> s = new TreeSet<>();
//
//		s.add("Ajay");
//		s.add("Sanju");
//		s.add("Arut");
//		s.add("z");
//		s.add("mnb");
//		s.add("Komal");
//		
//		System.out.println(s);
		
//		Map<Integer,String> m1 = new HashMap<>();
//		Map<Integer,String> m2 = new TreeMap<>();
//		
//		m1.put(11,"One");
//		m1.put(5,"five");
//		m1.put(55,"four");
//		m1.put(31,"three");
//		m1.put(32,"Second");
//		
//		System.out.println(m1);
//		System.out.println(m1.entrySet());
//		Set<Integer> keyset=m1.keySet();
//		for(Integer i : keyset) {
//			System.out.println(i+" "+m1.get(i));
//			
//		}
//		System.out.println();
//		for( Map.Entry<Integer, String> entry : m1.entrySet()) {
//			System.out.println(entry.getKey() + ": " + entry.getValue() );
//		}
//		System.out.println();
//		
//		m1.forEach( (k,v) -> System.out.println(k + ": " + v) );
//		
//		System.out.println();
//		
//		Set set =m1.entrySet();
//		Iterator ite = set.iterator();
//		while(ite.hasNext())
//		{
//			Map.Entry<Integer, String> entry = (Map.Entry<Integer, String>)ite.next();
//			System.out.println(entry.getKey()+" "+entry.getValue());
//			
//		}
//		
//		System.out.println(m1.getOrDefault(32, null));
		
		
//		System.out.println(m1.keySet());
//		System.out.println(m1.values());
//		
//		System.out.println(m1);
//		
//		
//		m2.putAll(m1);
//		System.out.println(m2);

		
		
			
	}

	}
