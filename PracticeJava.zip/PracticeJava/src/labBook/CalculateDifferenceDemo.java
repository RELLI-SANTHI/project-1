package labBook;
import java.math.*;
import java.util.Scanner;

public class CalculateDifferenceDemo {

	static int calculateDifference(int n) {
		int d=0;
		int x1=0;
		int x2=0;
		for(int i=1;i<=n;i++) {
			x1=x1+(int)Math.pow(i,2);
			
		}
		
		for(int i=1;i<=n;i++) {
			x2=x2+i;
		}
		
		return x1-(int)Math.pow(x2,2);
	}
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter input:");
		int n=sc.nextInt();
		System.out.println("sum="+calculateDifference(n));
	}

}
