package BasicJavaCodes;

public class AmstrongNumber {

	public static boolean isAmstrong(int n){
		int temp=n;
		int r,sum=0;
		int digits=0;
		
		while(n>0) {
			n=n/10;
			digits++;
		}
		temp=n;
		while(n>0) {
			r=n%10;
			sum=(int)(sum+(Math.pow(sum, digits)));
		}
		if(temp==sum)
			return true;
		else
			return false;
		
	}
	
	
	public static void main(String[] args) {
		

		int num=153;
		System.out.println(isAmstrong(num));
	}

}
