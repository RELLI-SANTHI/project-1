package BasicJavaCodes;

public class Palindrome {
	
	public static boolean isPalindrome(int n) {
		int temp=n;
		int b;
		int sum=0;
		while(n>0) {
		b=n%10;
		sum=(sum*10)+b;
		n=n/10;
		}
		if(temp==sum) 
			return true;
		else
			return false;
	}
	
	public static boolean isPalindrome(String str) {
		
		
		String reverseString ="";
		
		for(int i=str.length()-1; i>=0; i--) {
			char last = str.charAt(i);
			reverseString=reverseString+last;
		}
		
		if(str.equals(reverseString))
			return true;
		else
			return false;
	}
	

	public static void main(String[] args) {
	
		int num=141;
		
		System.out.println(isPalindrome(num));
		
		String st="KoK";
		System.out.println(isPalindrome(st));

		
	}

}
