package BasicJavaCodes;

import java.util.Random;

public class Reversing {
	
	public static int reverse(int n) {
		int b;
		int sum=0;
		while(n>0) {
		b=n%10;
		sum=(sum*10)+b;
		n=n/10;
		}
		return sum;
	}
	
	public static String reverse(String str) {
		String reverseString ="";
		
		for(int i=str.length()-1; i>=0; i--) {
			char last = str.charAt(i);
			reverseString=reverseString+last;
		}
		return reverseString;
	}

	public static void main(String[] args) {
		
		int num=176;
		String name="komal";
		System.out.println(reverse(num));
		System.out.println(reverse(name));
		System.out.println(Math.random()*(100-1+1)+1);
		
		Random r=new Random();
		System.out.println(r.nextInt(1000));
		
		

	}

}
