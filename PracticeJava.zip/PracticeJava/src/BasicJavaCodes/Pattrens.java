package BasicJavaCodes;

public class Pattrens {

	public static void main(String srgs[]) {
	
		int x=0;
		int num=6;
		
		
		for(int i=1;i<=num;i++) {

			for(int j=1;j<=num-i;j++) {
				System.out.print(" ");
			}
			for(int j=1;j<=i+x;j++) {
				System.out.print("*");
				
			}
			x=x+1;
		
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
//		for(int i=1; i<=6; i++) {
//			for(int j=1; j<=i;j++) {
//				System.out.print("*");
//			}
//			System.out.println();
//		}
//		System.out.println();
//	
//		for(int i=1; i<=6; i++) {
//			for(int j=1; j<=6-i; j++) {
//				System.out.print(" ");
//			}
//			for(int j=1; j<=i; j++) {
//				System.out.print("* ");
//			}
//			System.out.println();
//		}
//		
//		int count=1;
//		for(int i=1; i<=6; i++) {
//			for(int j=1; j<=i;j++) {
//				System.out.print(count+" ");
//				count++;
//			}
//			System.out.println();
//			
//		}
//		System.out.println();
//		int row1=6;
//		for(int i=1; i<=6; i++) {
//			for(int j=1; j<=row1-i; j++) {
//				System.out.print(" ");
//			}
//			for(int j=1; j<=i; j++) {
//				System.out.print(j);
//			}
//			System.out.println();
//		}
//		
//		
//		int rows=11;
//		int n=(rows/2)+1;
//		for(int i=1; i<=n; i++) {
//			for(int j=1; j<=n-i; j++) {
//				System.out.print(" ");
//			}
//			for(int j=1; j<=i; j++) {
//				System.out.print("$ ");
//			}
//			System.out.println();
//		}
//		for(int i=n-1; i>=1; i--) {
//			for(int j=1; j<=n-i; j++) {
//				System.out.print(" ");
//			}
//			for(int j=1; j<=i; j++) {
//				System.out.print("$ ");
//			}
//			System.out.println();
//		}
//		char ch='A';
//		for(int i=1; i<=6; i++) {
//			for(int j=1; j<=i;j++) {
//				System.out.print(ch+" ");
//				ch++;
//			}
//			System.out.println();
//		}
//		System.out.println();
		
		
		
}
}