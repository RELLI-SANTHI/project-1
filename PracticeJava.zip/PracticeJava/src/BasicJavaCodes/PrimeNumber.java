package BasicJavaCodes;

public class PrimeNumber {
	

	public static boolean isPrime(int num) {
		int flag=0;
		for(int j=2; j<=num/2; j++)
		{
			if(num%j==0) 
			{
				flag=1;
				break;
			}
		}
		
			if(flag==0) 
				return true;
			else
				return false;
		}
			
	

	public static void main(String[] args) {
		
		int n=20;
		for(int i=2; i<=n; i++)
		{
			if(isPrime(i)) 
			{System.out.println(i);}
			
		}
		
			
	}	
}
	


