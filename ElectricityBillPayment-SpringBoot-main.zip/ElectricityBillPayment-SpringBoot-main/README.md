# ElectricityBillPayment-SpringBoot
Electricity Bill Payment is my Spring Boot based project , in this project we can pay electricity bill by online, there are many feature we provided four user point of view , very easy to understand.
