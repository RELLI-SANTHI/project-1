package com.example.comcgspringmibiproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComCgSpringmibiProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
