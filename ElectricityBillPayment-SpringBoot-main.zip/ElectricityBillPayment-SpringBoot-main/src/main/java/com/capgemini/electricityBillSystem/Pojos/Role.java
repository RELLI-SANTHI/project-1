package com.capgemini.electricityBillSystem.Pojos;

public enum Role {

	ADMIN, CUSTOMER

}