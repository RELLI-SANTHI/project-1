//package com.capgemini.electricityBillSystem.Pojos;
//
//
//public enum PaymentStatus {
//	SUCCESS, FAILED
//}
