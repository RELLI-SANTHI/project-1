package com.capgemini.electricityBillSystem.Pojos;
public enum ConnectionType {
	NON_INDUSTRIAL, INDUSTRIAL, AGRICULTURAL
}
