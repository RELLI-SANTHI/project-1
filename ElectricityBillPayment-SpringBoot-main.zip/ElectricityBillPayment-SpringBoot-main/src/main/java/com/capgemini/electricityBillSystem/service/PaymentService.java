//package com.capgemini.electricityBillSystem.service;
//
//import java.util.List;
//
//import com.capgemini.electricityBillSystem.Pojos.Payment;
//import com.capgemini.electricityBillSystem.Pojos.PaymentStatus;
//
//public interface PaymentService {
//		
//		public PaymentStatus payBill(Payment payment) ;
//
//		public List<Payment> viewHistoricalPayment(Long consumerNumber);
//		
//		Payment getPaymentById(Long paymentId);
//		
//		List<Payment> getAllPayments();
//	}
//
