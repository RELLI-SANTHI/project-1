//package com.capgemini.electricityBillSystem.Pojos;
//
//
//public enum PaymentMode {
//	CREDIT, DEBIT, WALLET, NETBANKING
//}
